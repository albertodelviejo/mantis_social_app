#import <Flutter/Flutter.h>

@interface AppleSignInPlugin : NSObject<FlutterPlugin, FlutterStreamHandler>
@end
