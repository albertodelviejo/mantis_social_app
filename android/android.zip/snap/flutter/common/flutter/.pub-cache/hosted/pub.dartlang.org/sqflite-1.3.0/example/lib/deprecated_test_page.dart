import 'test_page.dart';

/// Deprecated test page.
class DeprecatedTestPage extends TestPage {
  /// Deprecated test page.
  DeprecatedTestPage() : super('Deprecated tests') {
    test('None', () async {});
  }
}
