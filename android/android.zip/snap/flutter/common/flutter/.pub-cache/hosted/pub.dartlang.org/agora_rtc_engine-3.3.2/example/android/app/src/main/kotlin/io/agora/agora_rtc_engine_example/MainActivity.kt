package io.agora.agora_rtc_engine_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
