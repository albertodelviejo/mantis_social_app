//
//  Utils.h
//  apple_sign_in
//
//  Created by Tom on 23/06/2019.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Utils : NSObject

+ (NSObject*)valueOrNSNull:(NSObject*)object;

@end

NS_ASSUME_NONNULL_END
