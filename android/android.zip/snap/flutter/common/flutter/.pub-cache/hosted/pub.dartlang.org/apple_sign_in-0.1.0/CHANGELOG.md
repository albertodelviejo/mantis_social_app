## 0.1.0

* Add `CredentialStatus.transferred`
* Added documentation
* API should now be stable

## 0.0.3

* Added `AuthorizationStatus.cancelled` value
* Added `CredentialStatus.transferred` value

## 0.0.2

* Added Flutter `AppleSignInButton` button
* Added `AppleSignIn.isAvailable()` method

## 0.0.1

* Initial preview
