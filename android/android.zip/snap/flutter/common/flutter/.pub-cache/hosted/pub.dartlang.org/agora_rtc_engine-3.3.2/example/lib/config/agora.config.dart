/// Get your own App ID at https://dashboard.agora.io/
const appId = YOUR_APP_ID;

/// Please refer to https://docs.agora.io/en/Agora%20Platform/token
const token = YOUR_TOEKN;

const channelId = YOUR_CHANNEL_ID;
const uid = YOUR_UID;
const stringUid = YOUR_STRING_UID;
