import 'package:agora_rtc_engine_example/examples/advanced/multi_channel.dart';

final Advanced = [
  {'name': 'Advanced'},
  {'name': 'MultiChannel', 'widget': MultiChannel()}
];
