#import <Flutter/Flutter.h>

@interface AgoraRtcEnginePlugin : NSObject<FlutterPlugin>
@end
